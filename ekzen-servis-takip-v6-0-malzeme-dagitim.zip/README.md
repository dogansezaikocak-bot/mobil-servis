# Ekzen Servis Takip V6.0

V5.2.0 Beta 2 Safari açılış düzeltmeli stabil sürüm temel alınmıştır.

## V6.0 yenilikleri
- Malzeme Dağıtım sekmesi
- Dükkân, adres, telefon, mahalle/grup ve çoklu malzeme kaydı
- Bekliyor → Hazırlandı → Yüklendi → Teslim Edildi iş akışı
- Durum sayaçları ve teslim ilerleme çubuğu
- Dükkân, adres ve malzeme araması
- Mahalle/grup ve durum filtreleri
- Telefon arama ve Google Maps konuma gitme
- Liste içe aktarma (satır/JSON)
- JSON yedek alma
- Veriler cihazda yerel olarak saklanır
