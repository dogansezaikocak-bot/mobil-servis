# Ekzen Servis Takip V6.1.1

V5.2.0 Beta 2 Safari uyumlu temel ve V6.0 dağıtım modülü korunmuştur.

## V6.1.1 yenilikleri
- Dağıtım ekranında **Fotoğraftan AI Oku** düğmesi
- iPhone/Android kamerasından fotoğraf çekme veya galeriden birden fazla sayfa seçme
- Görselleri küçültüp AI'ya gönderme
- Dükkân, adres, telefon, mahalle/grup ve malzemeleri JSON olarak çıkarma
- Aynı dükkâna ait ardışık malzeme satırlarını birleştirme
- Okunan kayıtları kaydetmeden önce ön izleme ve hatalı satırı silme
- Mevcut listeye ekleme veya listeyi değiştirme
- Mahalle/grup eşleme kuralları

## Kullanım
Dağıtım > Fotoğraftan AI Oku > fotoğrafları seç > API anahtarı veya güvenli bağlantı adresi gir > AI ile Oku > kontrol et > Listeye Kaydet.

API anahtarı doğrudan kullanımda yalnızca açık sekmenin belleğinde kalır; uygulamanın localStorage verisine kaydedilmez. Daha güvenli kullanım için `cloudflare-worker-openai-proxy.js` dosyasını Worker olarak kurup `OPENAI_API_KEY` secret ekleyin ve Worker adresini uygulamadaki "Güvenli AI bağlantısı" alanına yazın.


## V6.1.1 düzeltmesi
- iPhone/Safari'de galeriden seçilen fotoğrafın algılanmaması düzeltildi.
- Galeri ve kamera seçenekleri ayrıldı.
- Fotoğraf küçültme başarısız olursa orijinal dosya kullanılır.
